function função1() {
    alert('tue sub 9')
}
function função3 () {
    let nome = window. prompt('qual seu nome?')
   paragrafo.innerHTML = nome
}